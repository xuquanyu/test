# nodejs 客户端

现已实现同步查询，异步查询未实现，用法参考 test.js
